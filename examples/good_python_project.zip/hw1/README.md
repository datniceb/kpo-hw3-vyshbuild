# ДЗ-1
Запуск: python main.py
